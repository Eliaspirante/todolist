Utils = {
	userOrganizationFieldTypes: {
		'lista suspensa': 'dropdown',
		'lista': 'dropdown',
		'texto': 'text',
		'caixa de seleção': 'checkbox',
		'texto multilinha': 'textarea',
		'multilinhas': 'textarea',
		'data': 'date'
	},
	ticketFieldTypes: {
		'lista suspensa': 'tagger',
		'lista': 'tagger',
		'texto': 'text',
		'caixa de seleção': 'checkbox',
		'caixa de seleçao': 'checkbox',
		'caixa de selecao': 'checkbox',
		'texto multilinha': 'textarea',
		'multilinhas': 'textarea',
		'seleção multipla': 'multiselect',
		'data': 'date'
	},
	mapFieldType: {
		'ticket_fields': 'ticket_field',
		'user_fields': 'user_field',
		'organization_fields': 'organization_field',
		'triggers': 'trigger',
		'macros': 'macro',
	},
	ticketStatusType: {
		'pendente': 'pending',
		'resolvido': 'solved',
		'aberto': 'open',
		'em espera': 'hold',
		'espera': 'hold',
		'novo': 'new',
	},
	RemoveNewLinesWhiteSpaces: function(str) {
		return str.replace(/(\r\n|\n|\r)/gm, "").trim();
	},
	RemoveAccents: function(str) {
	  var accents    = 'ÀÁÂÃÄÅàáâãäåÒÓÔÕÕÖØòóôõöøÈÉÊËèéêëðÇçÐÌÍÎÏìíîïÙÚÛÜùúûüÑñŠšŸÿýŽž';
	  var accentsOut = "AAAAAAaaaaaaOOOOOOOooooooEEEEeeeeeCcDIIIIiiiiUUUUuuuuNnSsYyyZz";
	  str = str.split('');
	  var strLen = str.length;
	  var i, x;
	  for (i = 0; i < strLen; i++) {
	    if ((x = accents.indexOf(str[i])) != -1) {
	      str[i] = accentsOut[x];
	    }
	  }
	  return str.join('');
	},
	makeStringForKey: (str) => {
		var strLen = str.length;
		var i, x;
		str = str.replace(/(\r\n|\n|\r|\t)/gm, "").trim();
		for (i = 0; i < strLen; i++) {
			str = str
			.replace('?', '')
			.replace('!', '')
			.replace(' :: ', '_')
			.replace(' ::', '_')
			.replace(':: ', '_')
			.replace('::', '_')
			.replace(' : ', '_')
			.replace(' :', '_')
			.replace(': ', '_')
			.replace(':', '_')
			.replace(' - ', '_')
			.replace(' -', '_')
			.replace('- ', '_')
			.replace('-', '_')
			.replace(' – ', '_')
			.replace(' –', '_')
			.replace('– ', '_')
			.replace('–', '_')
			.replace(' + ', '_')
			.replace(' +', '_')
			.replace('+ ', '_')
			.replace('+', '_')
			.replace('&', 'e')
			.replace('.', '')
			.replace(',', '')
			.replace(' < ', '_')
			.replace(' <', '_')
			.replace('< ', '_')
			.replace('<', '_')
			.replace(' > ', '_')
			.replace('> ', '_')
			.replace(' >', '_')
			.replace('>', '_')
			.replace('(', '')
			.replace(')', '')
			.replace('[', '')
			.replace(']', '')
			.replace('{', '')
			.replace('}', '')
			.replace(' / ', '_')
			.replace(' /', '_')
			.replace('/ ', '_')
			.replace('/', '_')
			.replace(' | ', '_')
			.replace(' |', '_')
			.replace('| ', '_')
			.replace('|', '_')
			.replace("\\'")
			.replace('´')
			.replace(' \\ ', '_')
			.replace('\\ ', '_')
			.replace(' \\', '_')
			.replace('\\', '_')
			.replace('   ', ' ')
			.replace('  ', ' ')
			.replace('º','')
			.replace('°','')
			.replace('ª','')
			.replace('ª','')
			.replace('³','3');
		}

		return Utils.RemoveAccents(str).replace(/[`~!@#$%^&*()|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '').split(' ').join('_').replace(/ /g,'').replace(/___/g,'_').replace(/__/g,'_').toLowerCase();
	}
}



module.exports = Utils;