process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const Papa = require('papaparse');
const zendeskDomain = 'serasab2b';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let incrementalBaseUrl = `${baseUrlZendesk}/api/v2/triggers`;
let dataToSave = [];

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getTicketsIncremental(urlToUse){
  configZendesk.url = urlToUse?urlToUse:incrementalBaseUrl;

//   console.log('url', configZendesk.url);

  try{
    let responseForms = await axios(configZendesk);

    if(!responseForms.data.triggers){
        return;
    }

    let triggers = responseForms.data.triggers;

    let linhaHeader = [];
    
    linhaHeader.push("ID gatilho");
    linhaHeader.push("Gatilho ativo?");
    linhaHeader.push("Título gatilho");
    linhaHeader.push("Marca");
    linhaHeader.push("Grupo");
    // linhaHeader.push("Título");
    // linhaHeader.push("Conteúdo");
    dataToSave.push(linhaHeader);

    for(let i = 0; i < triggers.length; i++){
      let trigger = triggers[i];
        let linha = [];
      if(!trigger.active){
        continue;
      }

      let brandid = '';
      let whonotification = '';
      let notificationUser = '';
      let notificationTitle = '';
      let novoStatus = '';
    
      let isnotificationtrigger = false;
      for(let j = 0; j < trigger.conditions.all.length; j++){
        if(trigger.conditions.all[j].field == 'brand_id'){
            brandid = trigger.conditions.all[j].value;
        }
      }

      for(let j = 0; j < trigger.actions.length; j++){
        let action = trigger.actions[j];

        if(action.field != 'group_id'){
            continue;
        }
        
        isnotificationtrigger = true;
        novoStatus = action.value;
        // whonotification = action.value[0];
        // notificationTitle = action.value[1];
        // notificationUser = action.value[2];
        break;
      }
      
      if(isnotificationtrigger){
        // dataToSave += `${trigger.id};${trigger.active};${trigger.title};${brandid};${whonotification};${notificationTitle};${notificationUser}\n`;

        linha.push(trigger.id);
        linha.push(trigger.active);
        linha.push(trigger.title);
        linha.push(brandid);
        linha.push(novoStatus);
        // linha.push(whonotification);
        // linha.push(notificationTitle);
        // linha.push(notificationUser);

        dataToSave.push(linha);
        //console.log(`${trigger.id};${trigger.active};${trigger.title};${brandid};${whonotification};${notificationTitle};${JSON.parse(notificationUser)}`);
      }
    }

    if(responseForms.data.next_page && responseForms.data.next_page != urlToUse){
      await getTicketsIncremental(responseForms.data.next_page);
    }
	}catch(error){
		console.log('error forms', configZendesk.url, error);
	}
}

async function main(){
//   console.log('main');

    await getTicketsIncremental();

    let csv = Papa.unparse(dataToSave, {delimiter: ";",
        quotes: true,
        quoteChar: '"'
    });

    console.log(csv);

let arquivo = '';
for(let i = 0; i < csv.length; i++){
    arquivo += csv[i];
}
  fs.writeFileSync('./triggers_grupos.csv', arquivo, 'utf8');
//   console.log('fim processo');
}


main();
