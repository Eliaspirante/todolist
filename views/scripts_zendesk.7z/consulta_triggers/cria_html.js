const fs = require('fs');
const Papa = require('papaparse');

let arquivoBaseHtml = fs.readFileSync('base_html.html', 'utf8');
let arquivoTratar = fs.readFileSync('triggers.csv', 'utf8');
// arquivoTratar = arquivoTratar.split('\n');

Papa.parse(arquivoTratar, {delimiter: ";",
    quoteChar: '"',
    complete: function(results) {
        console.log(results);
        for(let i = 0; i < results.data.length; i++){
            let linha = results.data[i];
        
            // console.log(linha[0],linha[2]);
            let html = arquivoBaseHtml;

            let tmpContent = linha[6].replace(/\n/g, '<br>')
            html = html.replace('{{content}}', '<h2>'+linha[5]+'</h2><br><br><br><br>'+tmpContent);

            fs.writeFileSync(`./htmls/${linha[0]}-${linha[2]}.html`, html, 'utf8');
        }
    }
});
