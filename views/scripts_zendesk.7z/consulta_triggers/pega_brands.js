process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const Papa = require('papaparse');
const zendeskDomain = 'serasab2b';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let incrementalBaseUrl = `${baseUrlZendesk}/api/v2/brands`;
let dataToSave = [];

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getTicketsIncremental(urlToUse){
  configZendesk.url = urlToUse?urlToUse:incrementalBaseUrl;

//   console.log('url', configZendesk.url);

  try{
    let responseForms = await axios(configZendesk);

    if(!responseForms.data.brands){
        return;
    }

    let triggers = responseForms.data.brands;

    for(let i = 0; i < triggers.length; i++){
      let trigger = triggers[i];
        let linha = [];

        // dataToSave += `${trigger.id};${trigger.active};${trigger.title};${brandid};${whonotification};${notificationTitle};${notificationUser}\n`;

        linha.push(trigger.id);
        linha.push(trigger.signature_template);

        dataToSave.push(linha);
        //console.log(`${trigger.id};${trigger.active};${trigger.title};${brandid};${whonotification};${notificationTitle};${JSON.parse(notificationUser)}`);
    }

    if(responseForms.data.next_page && responseForms.data.next_page != urlToUse){
      await getTicketsIncremental(responseForms.data.next_page);
    }
	}catch(error){
		console.log('error forms', configZendesk.url, error);
	}
}

async function main(){
//   console.log('main');

    await getTicketsIncremental();

    let csv = Papa.unparse(dataToSave, {delimiter: ";",
        quotes: true,
        quoteChar: '"'
    });

    console.log(csv);

let arquivo = '';
for(let i = 0; i < csv.length; i++){
    arquivo += csv[i];
}
  fs.writeFileSync('./brands.csv', arquivo, 'utf8');
//   console.log('fim processo');
}


main();
