process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const { getGrupos, findGrupo } = require('./grupos');
const {getTicketFields, findTicketField} = require('./ticket_fields');
const {getBrands, findBrand} = require('./brands');
const { convert } = require('html-to-text');

const zendeskDomain = 'serasab2b';
//const zendeskDomain = 'serasab2b1663597678';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const tokenSandbox = 'GImoau5pARIjc2bSCojYugnf9MrVvsz7RTvumX9n';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let macrosUrl = `${baseUrlZendesk}/api/v2/macros.json?include=usage_30d,usage_7d,usage_24h`;

let macrosToSave = 'ID Macro;Titulo Macro;Ativa;Comentario;Marca;Grupo;Uso 30 dias;Uso 7 dias;Uso 24 horas;Primeiro Grupo;Grupos de restrição\n';

let totalMacros = 0;
let totalMacrosInativas = 0;
let totalMacrosAtivas = 0;
let totalMacrosPorGrupo = {};
let firstResponse = true;

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getMacros(urlToUse){
  configZendesk.url = urlToUse?urlToUse:macrosUrl;

  console.log('url', configZendesk.url);

  try{
		let responseZendesk = await axios(configZendesk);

		if(!responseZendesk.data.macros){
			return;
		}

    if(firstResponse){
        totalMacros = responseZendesk.data.count;
        firstResponse = false;
    }

    let macros = responseZendesk.data.macros;

    for(let i = 0; i < macros.length; i++){
      let macro = macros[i];

      let tmpMacroToSave = '';

      let tags = '';
      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];

        if(action.field == 'current_tags'){
          if(tags.length > 0){
            tags += ' ';  
          }
          
          tags += action.value;
        }
      }

      let addMacro = false;
      let fieldValue = '';
      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];

        if(action.field == 'comment_value_html'){
          addMacro = true;
          fieldValue = convert(action.value).replace(/\"/g, '\'')
        }
      }

      let addMacro2 = false;
      let fieldValue2 = '';
      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];

        if(action.field == 'brand_id'){
          addMacro2 = true;
          fieldValue2 = action.value;
          let tmpBrand = findBrand(action.value);
          if(tmpBrand){
            fieldValue2 = `${tmpBrand.name};`;
          }
        }
      }

      let addMacro3 = false;
      let fieldValue3 = '';
      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];

        if(action.field == 'group_id'){
          addMacro3 = true;
          fieldValue3 = action.value;
          let tmpGroup = findGrupo(action.value);
          console.log('GRUPO', action.value, tmpGroup);
          if(tmpGroup){
            fieldValue3 = `${tmpGroup.name};`;
          }
        }
      }

      tmpMacroToSave += `${macro.id};${macro.title};${macro.active};"${fieldValue}";${fieldValue2};${fieldValue3};${macro.usage_30d};${macro.usage_7d};${macro.usage_24h}`;

      if(macro.active){
        totalMacrosAtivas++;
      }else{
        totalMacrosInativas++;
      }

      let tmpGroupsStr = '';
      let firstGroup = '';
      let foundLag = true;
      if(macro.restriction && macro.restriction.type === 'Group'){
        for(let k = 0; k < macro.restriction.ids.length; k++){
          let tmpGroup = findGrupo(macro.restriction.ids[k]);
          if(tmpGroup){// && tmpGroup.name.indexOf('LAG') > -1
            foundLag = true;
            if(firstGroup == ''){
              firstGroup = tmpGroup.name;
            }
            if(tmpGroupsStr != ''){
              tmpGroupsStr += ',';
            }
            tmpGroupsStr += `${tmpGroup.name}`;
            if(!totalMacrosPorGrupo[macro.restriction.ids[k]]){
                totalMacrosPorGrupo[macro.restriction.ids[k]] = 0;
            }

            totalMacrosPorGrupo[macro.restriction.ids[k]]++;
          }
        }
      }

      // if(!foundLag){
      //   tmpMacroToSave = '';
      //   continue;
      // }
      tmpMacroToSave += `;${firstGroup};${tmpGroupsStr}\n`;

      if(tmpMacroToSave){
        macrosToSave += tmpMacroToSave;
      }
    }

    if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
      // await timeout(350);
      await getMacros(responseZendesk.data.next_page);
    }
	}catch(error){
		console.log('error macros', configZendesk.url, error);
	}
}

async function main(){
  console.log('main');

  await getBrands(`${baseUrlZendesk}/api/v2/brands.json`,configZendesk);
  await getGrupos(`${baseUrlZendesk}/api/v2/groups.json`,configZendesk);
  await getMacros();

  macrosToSave += `\n\n\n`;
  macrosToSave += `Total macros:${totalMacros}\n`;
  macrosToSave += `Total macros ativas:${totalMacrosAtivas}\n`;
  macrosToSave += `Total macros inativas:${totalMacrosInativas}\n\n`;

  macrosToSave += `Total de macros por grupo\n`;
  macrosToSave += `ID grupo;Nome grupo;Ativo;Total macros\n`;
  for(let key in totalMacrosPorGrupo){
    let tmpGroup = findGrupo(key);
    macrosToSave += `${key};${tmpGroup.name};${tmpGroup.deleted?'desativado':'ativo'};${totalMacrosPorGrupo[key]}\n`;
  }

  fs.writeFileSync('./report_macros.csv', macrosToSave, 'utf8');

  console.log('fim processo');
}


main();
