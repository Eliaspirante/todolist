process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');

let grupos = [];
const objectToGet = 'custom_roles';
async function getCustomRoles(url, configZendesk){
    console.log(configZendesk);
    await getCustomRolesZendesk(url, configZendesk);
}

async function getCustomRolesZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            grupos = grupos.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getCustomRolesZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error grupos', configZendesk.url, error);
    }
}

function findCustomRole(id){    
    return grupos.find((item) => {
        return item.id == id;
    });
}

function findCustomeRoleByName(name){    
    return grupos.find((item) => {
        return item.name == name;
    });
}

function findCustomeRoleByStartName(name){
    return grupos.filter((item) => {
        return item.name.startsWith(name);
    });
}

module.exports = {getCustomRoles, findCustomRole, findCustomeRoleByName, findCustomeRoleByStartName};