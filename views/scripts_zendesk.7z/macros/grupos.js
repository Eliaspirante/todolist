process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');

let grupos = [];
const objectToGet = 'groups';
async function getGrupos(url, configZendesk){
    console.log(configZendesk);
    await getGruposZendesk(url, configZendesk);
}

async function getGruposZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            grupos = grupos.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getGruposZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error grupos', configZendesk.url, error);
    }
}

function findGrupo(id){    
    return grupos.find((item) => {
        return item.id == id;
    });
}

function findGrupoByName(name){    
    return grupos.find((item) => {
        return item.name == name;
    });
}

function findGruposByStartName(name){
    return grupos.filter((item) => {
        return item.name.startsWith(name);
    });
}

module.exports = {getGrupos, findGrupo, findGrupoByName, findGruposByStartName};