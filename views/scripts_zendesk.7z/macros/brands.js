process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');

let brands = [];
const objectToGet = 'brands';

async function getBrands(url, configZendesk){
    // console.log(configZendesk);
    await getBrandsZendesk(url, configZendesk);
}

async function getBrandsZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            brands = brands.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getBrandsZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error '+objectToGet, configZendesk.url, error);
    }
}

function findBrand(id){    
    return brands.find((item) => {
        return item.id == id;
    });
}

module.exports = {getBrands, findBrand};