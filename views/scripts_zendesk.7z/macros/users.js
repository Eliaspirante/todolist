process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');
const fs = require('fs');

const zendeskDomain = 'serasab2b';

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;

let users = [];
const objectToGet = 'users';
let usersURL = `${baseUrlZendesk}/api/v2/users`;

function readUserFromFile(){
    let tmpData = fs.readFileSync('C:/Users/c99229a/workspace/scripts_zendesk/macros/userssearched.json', 'utf8');

    if(tmpData && tmpData != ''){
        users = JSON.parse(tmpData);
    }
}

async function getUsers(url, configZendesk){
    console.log(configZendesk);
    await getUsersZendesk(url, configZendesk);
}

async function getUsersZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            users = users.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getUsersZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error '+objectToGet, configZendesk.url, error);
    }
}

async function findUserById(id, configZendesk){    
    let tmpUser = users.find((item) => {
        return item.id == id;
    });

    if(!tmpUser){
        configZendesk.url = `${usersURL}/${id}`;
        // console.log('consulta user'+ configZendesk.url);
        try{
            let responseZendesk = await axios(configZendesk);

            if(!responseZendesk.data.user){
                return undefined;
            }

            tmpUser = responseZendesk.data.user;

            users.push(tmpUser);
        }catch(e){
            console.log('error during get user', e);
        }
    }

    return tmpUser;
}

function saveUsersFileJSON(){
    fs.writeFileSync('C:/Users/c99229a/workspace/scripts_zendesk/macros/userssearched.json', JSON.stringify(users), 'utf8');
}

function getUsersArray(){
    return users;
}

module.exports = {getUsers, findUserById, saveUsersFileJSON, readUserFromFile, getUsersArray};