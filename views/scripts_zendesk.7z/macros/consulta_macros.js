process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const { getGrupos, findGrupo } = require('./grupos');
const {getTicketFields, findTicketField} = require('./ticket_fields');
const {getBrands, findBrand} = require('./brands');

const zendeskDomain = 'serasab2b';
//const zendeskDomain = 'serasab2b1663597678';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const tokenSandbox = 'GImoau5pARIjc2bSCojYugnf9MrVvsz7RTvumX9n';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let macrosUrl = `${baseUrlZendesk}/api/v2/macros.json`;

let macrosToSave = '';

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getMacros(urlToUse){
  configZendesk.url = urlToUse?urlToUse:macrosUrl;

  console.log('url', configZendesk.url);

  try{
		let responseZendesk = await axios(configZendesk);

		if(!responseZendesk.data.macros){
			return;
		}

    let macros = responseZendesk.data.macros;

    for(let i = 0; i < macros.length; i++){
      let macro = macros[i];
      
      let tmpMacroToSave = `${macro.id};${macro.title};${macro.active}\n`;
      let foundLag = true;

      if(macro.restriction && macro.restriction.type === 'Group'){
        let tmpGroupsStr = '';

        for(let k = 0; k < macro.restriction.ids.length; k++){
          let tmpGroup = findGrupo(macro.restriction.ids[k]);
          if(tmpGroup){// && tmpGroup.name.indexOf('LAG') > -1
            foundLag = true;
            if(tmpGroupsStr != ''){
              tmpGroupsStr += ',';
            }
            tmpGroupsStr += `${tmpGroup.name}`;
          }
        }

        if(macro.restriction.ids.length > 0){
          tmpMacroToSave += 'Grupos de restrição;';
        }
        tmpMacroToSave += `${tmpGroupsStr}\n`;
      }

      if(!foundLag){
        tmpMacroToSave = '';
        continue;
      }

      tmpMacroToSave += `AÇÕES:::\n`;
      tmpMacroToSave += `Campo;Nome Zendesk;Valor\n`;
      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];
        tmpMacroToSave += `${action.field};`;
        if(action.field.indexOf('custom_fields_') > -1){
          let tmpTicketField = findTicketField(action.field.replace('custom_fields_',''));
          if(tmpTicketField){
            tmpMacroToSave += `${tmpTicketField.title};`;
          }
        }else if(action.field.indexOf('brand_id') > -1){
          let tmpBrand = findBrand(action.value);
          if(tmpBrand){
            tmpMacroToSave += `${tmpBrand.name};`;
          }
        }else if(action.field.indexOf('group_id') > -1){
          let tmpGroup = findGrupo(action.value);
          if(tmpGroup){
            tmpMacroToSave += `${tmpGroup.name};`;
          }
        }else{
          tmpMacroToSave += `;`;
        }

        tmpMacroToSave += `"${action.value}"\n`;
      }

      tmpMacroToSave += `\n\n`;

      if(foundLag){
        macrosToSave += tmpMacroToSave;
      }
      
    }

    if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
      // await timeout(350);
      await getMacros(responseZendesk.data.next_page);
    }
	}catch(error){
		console.log('error macros', configZendesk.url, error);
	}
}

async function main(){
  console.log('main');

  await getBrands( `${baseUrlZendesk}/api/v2/brands.json`,configZendesk);
  await getTicketFields( `${baseUrlZendesk}/api/v2/ticket_fields.json`,configZendesk);
  await getGrupos( `${baseUrlZendesk}/api/v2/groups.json`,configZendesk);
  await getMacros();

  fs.writeFileSync('./macros.csv', macrosToSave, 'utf8');

  console.log('fim processo');
}


main();
