process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const { getGrupos, findGrupo } = require('./grupos');

const zendeskDomain = 'serasab2b';
//const zendeskDomain = 'serasab2b1663597678';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const tokenSandbox = 'GImoau5pARIjc2bSCojYugnf9MrVvsz7RTvumX9n';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let viewsURL = `${baseUrlZendesk}/api/v2/views.json`;

let viewsToSave = '';
let gruposEncontrar = [4414983895187] 

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getViews(urlToUse){
  configZendesk.url = urlToUse?urlToUse:viewsURL;

  console.log('url', configZendesk.url);

  try{
		let responseZendesk = await axios(configZendesk);

		if(!responseZendesk.data.views){
			return;
		}

    let views = responseZendesk.data.views;

    for(let i = 0; i < views.length; i++){
      let view = views[i];
      
      let tmpMacroToSave = `${view.id};${view.title};${view.active};`;
      let foundLag = false;

      if(view.restriction && view.restriction.type === 'Group'){
        let tmpGroupsStr = '';

        for(let k = 0; k < view.restriction.ids.length; k++){
         
          if(!gruposEncontrar.includes(view.restriction.ids[k])){
            continue;
          }

          let tmpGroup = findGrupo(view.restriction.ids[k]);
          if(tmpGroup){// && tmpGroup.name.indexOf('LAG') > -1
            foundLag = true;
            if(tmpGroupsStr != ''){
              tmpGroupsStr += ',';
            }
            tmpGroupsStr += `${tmpGroup.name}`;
          }
        }

        if(view.restriction.ids.length > 0){
          tmpMacroToSave += 'Grupos de restrição;';
        }
        tmpMacroToSave += `${tmpGroupsStr}`;
      }

      tmpMacroToSave += `\n`;

      if(foundLag){
        viewsToSave += tmpMacroToSave;
      }
      
    }

    if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
      // await timeout(350);
      await getViews(responseZendesk.data.next_page);
    }
	}catch(error){
		console.log('error views', configZendesk.url, error);
	}
}

async function main(){
  console.log('main');

  await getGrupos( `${baseUrlZendesk}/api/v2/groups.json`,configZendesk);
  await getViews();

  fs.writeFileSync('./views.csv', viewsToSave, 'utf8');

  console.log('fim processo');
}


main();
