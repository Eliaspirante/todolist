process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');
const { getGrupos, findGrupo } = require('./grupos');
const {getTicketFields, findTicketField} = require('./ticket_fields');
const {getBrands, findBrand} = require('./brands');
const { convert } = require('html-to-text');

const zendeskDomain = 'serasab2b';
//const zendeskDomain = 'serasab2b1663597678';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const tokenSandbox = 'GImoau5pARIjc2bSCojYugnf9MrVvsz7RTvumX9n';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let macrosUrl = `${baseUrlZendesk}/api/v2/macros.json`;

let macrosToSave = '"ID macro";"Titulo";"Ativa?";"Grupo(s) Restrição";"Comentário"\n';

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getMacros(urlToUse){
  configZendesk.url = urlToUse?urlToUse:macrosUrl;

  console.log('url', configZendesk.url);

  try{
		let responseZendesk = await axios(configZendesk);

		if(!responseZendesk.data.macros){
			return;
		}

    let macros = responseZendesk.data.macros;

    for(let i = 0; i < macros.length; i++){
      let macro = macros[i];
      let tmpMacroToSave = '';
      
      let tmpLineToSave = `"${macro.id}";"${macro.title}";"${macro.active}";`;
      let foundLag = true;

      let tmpGroupsStr = '';
      if(macro.restriction && macro.restriction.type === 'Group'){
    
        for(let k = 0; k < macro.restriction.ids.length; k++){
          let tmpGroup = findGrupo(macro.restriction.ids[k]);
          if(tmpGroup){// && tmpGroup.name.indexOf('LAG') > -1
            foundLag = true;
            if(tmpGroupsStr != ''){
              tmpGroupsStr += ',';
            }
            tmpGroupsStr += `${tmpGroup.name}`;
          }
        }
      }
      tmpLineToSave += `"${tmpGroupsStr}"`;

      for(let j = 0; j < macro.actions.length; j++){
        let action = macro.actions[j];
        if(action.field.indexOf('comment_value_html') < 0){
          continue;
        }

        tmpMacroToSave += `${tmpLineToSave};"${convert(action.value).replace(/\"/g, '\'')}"\n`;
      }

      if(foundLag){
        macrosToSave += tmpMacroToSave;
      }
      
    }

    if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
      // await timeout(350);
      await getMacros(responseZendesk.data.next_page);
    }
	}catch(error){
		console.log('error macros', configZendesk.url, error);
	}
}

async function main(){
  console.log('main');

  await getBrands( `${baseUrlZendesk}/api/v2/brands.json`,configZendesk);
  await getTicketFields( `${baseUrlZendesk}/api/v2/ticket_fields.json`,configZendesk);
  await getGrupos( `${baseUrlZendesk}/api/v2/groups.json`,configZendesk);
  await getMacros();

  fs.writeFileSync('./macros_comentarios.csv', macrosToSave, 'utf8');

  console.log('fim processo');
}


main();
