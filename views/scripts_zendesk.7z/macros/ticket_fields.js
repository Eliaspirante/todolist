process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');

let ticketFields = [];
const objectToGet = 'ticket_fields';

async function getTicketFields(url, configZendesk){
    console.log(configZendesk);
    await getTicketFieldsZendesk(url, configZendesk);
}

async function getTicketFieldsZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    let ticketField = {"ticket_field":{"url":"https://serasab2b1729187684.zendesk.com/api/v2/ticket_fields/34499711052051.json","id":34499711052051,"type":"tagger","title":"LAG - Sub motivo - Balanço - Interno","raw_title":"LAG - Sub motivo - Balanço - Interno","description":"","raw_description":"","position":9999,"active":true,"required":false,"collapsed_for_agents":false,"regexp_for_validation":null,"title_in_portal":"LAG - Sub motivo - Balanço - Interno","raw_title_in_portal":"LAG - Sub motivo - Balanço - Interno","visible_in_portal":false,"editable_in_portal":false,"required_in_portal":false,"agent_can_edit":true,"tag":null,"created_at":"2024-10-17T18:00:30Z","updated_at":"2024-10-17T18:00:30Z","removable":true,"key":null,"agent_description":null,"custom_field_options":[{"id":34499711051539,"name":"captura","raw_name":"captura","value":"lag_sub_mot_balanco_interno_captura","default":false},{"id":34499711051667,"name":"atualizar","raw_name":"atualizar","value":"lag_sub_mot_balanco_interno_atualizar","default":false}]}}
    
    ticketField.ticket_field.custom_field_options
    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            ticketFields = ticketFields.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getTicketFieldsZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error '+objectToGet, configZendesk.url, error);
    }
}

function findTicketField(id){    
    return ticketFields.find((item) => {
        return item.id == id;
    });
}

function findTicketFieldByTitle(title){    
    return ticketFields.find((item) => {
        return item.title.trim().toLowerCase() == title.trim().toLowerCase();
    });
}

module.exports = {getTicketFields, findTicketField, findTicketFieldByTitle};