process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const axios = require('axios');

let macros = [];
const objectToGet = 'macros';

async function getMacros(url, configZendesk){
    console.log(configZendesk);
    return await getMacrosZendesk(url, configZendesk);
}

async function getMacrosZendesk(urlToUse, configZendesk){
    configZendesk.url = urlToUse;

    console.log('url', configZendesk.url);

    try{
        let responseZendesk = await axios(configZendesk);

        if(!responseZendesk.data[objectToGet]){
            return;
        }

        if(responseZendesk.data[objectToGet]){
            macros = macros.concat(responseZendesk.data[objectToGet]);
        }

        if(responseZendesk.data.next_page && responseZendesk.data.next_page != urlToUse){
        // await timeout(350);
            await getMacrosZendesk(responseZendesk.data.next_page, configZendesk);
        }
    }catch(error){
        console.log('error '+objectToGet, configZendesk.url, error);
    }
}

function findMacroField(id){    
    return macros.find((item) => {
        return item.id == id;
    });
}

function findMacrodByTitle(title){    
    return macros.find((item) => {
        return item.title.trim().toLowerCase() == title.trim().toLowerCase();
    });
}

function findMacroByIdGroupPermission(idGroup){
    return macros.filter((item) => {
        return item.restriction && ((item.restriction.id && item.restriction.id == idGroup) || (item.restriction.ids && item.restriction.ids.indexOf(idGroup)> -1));
    });
}

function findMacroByAction(field, value){
    return macros.filter((item) => {
        for(let i = 0; i < item.actions.length; i++){
            if(item.actions[i].field == field && item.actions[i].value == value){
                return true;
            }
        }
        
        return false;
    });
}

module.exports = {getMacros, findMacroField, findMacrodByTitle, findMacroByAction, findMacroByIdGroupPermission};