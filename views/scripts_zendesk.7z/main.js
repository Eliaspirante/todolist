process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 0;
const fs = require('fs');
const axios = require('axios');

const zendeskDomain = 'serasab2b';
//const zendeskDomain = 'serasab2b1663597678';

const tokenProd = 'nQ2JmD8jKgzHUENGaFDD5pjfwVZC4si381XsZTyN';
const tokenSandbox = 'GImoau5pARIjc2bSCojYugnf9MrVvsz7RTvumX9n';
const token = Buffer.from(`diego.souza@br.experian.com/token:${tokenProd}`).toString('base64');

const baseUrlZendesk = `https://${zendeskDomain}.zendesk.com`;
const configZendesk = {
  method: 'get',
  url: baseUrlZendesk,
  headers: {
    'Authorization': `Basic ${token}`
  }
}

let incrementalBaseUrl = `${baseUrlZendesk}/api/v2/incremental/tickets.json?start_time=1679799600`;

function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function getTicketsIncremental(urlToUse){
  configZendesk.url = urlToUse?urlToUse:incrementalBaseUrl;

  console.log('url', configZendesk.url);

  try{
		let responseForms = await axios(configZendesk);

		if(!responseForms.data.tickets){
			return;
		}

    let tickets = responseForms.data.tickets;

    for(let i = 0; i < tickets.length; i++){
      let ticket = tickets[i];
      if(!ticket.assignee_id){
        continue;
      }
      console.log(`${ticket.id};${ticket.assignee_id};${ticket.status};${ticket.group_id}`);
    }

    if(responseForms.data.next_page && responseForms.data.next_page != urlToUse){
      await timeout(9000);
      getTicketsIncremental(responseForms.data.next_page);
    }
	}catch(error){
		console.log('error forms', configZendesk.url, error);
	}
}

async function main(){
  console.log('main');

  await getTicketsIncremental();

  console.log('fim processo');
}


main();
